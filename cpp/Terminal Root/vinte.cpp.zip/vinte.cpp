export module helloworld;
import <iostream>;
 
export void hello() {
    std::cout << "Hello world!\n";
}
