# Snake Game

Dependências:
+ [ncurses dev](https://ncurses.dev/)

Compile:
```sh
make
./snakegame
```
