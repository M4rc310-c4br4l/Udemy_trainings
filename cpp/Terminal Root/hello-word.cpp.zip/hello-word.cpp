/* Meu primeiro C++ */
#include <iostream>
// Comentário 1
int main(){ // função main obrigatória
  std::cout << "Olá, Mundo!" << '\n'; // Imprime o conteúdo
  /*
   Final da função
   */
  return 0;
} /* finaliza a função */
