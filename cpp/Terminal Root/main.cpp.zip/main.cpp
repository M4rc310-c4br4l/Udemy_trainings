// main.cpp
#include <iostream>

import math;

int main(){
  std::cout << add(2000, 20) << '\n';
  return 0;
}
