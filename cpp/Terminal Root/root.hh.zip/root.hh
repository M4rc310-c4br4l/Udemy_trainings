#ifndef ROOT_H
#define ROOT_H
namespace root{
  class Terminal{
    public:
      void terminal(){
        std::cout << "Minha função membro número 1" << '\n';
      }

      void root(){
        std::cout << "Minha função membro número 2" << '\n';
      }

  };
}

#endif
