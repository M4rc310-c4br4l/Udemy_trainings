#include "snakegame.hh"

int main( int argc , char **argv ){
  SnakeGame s;
  s.start();
  return 0;
}

