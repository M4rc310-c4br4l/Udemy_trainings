#ifndef PROJECT_H
#define PROJECT_H
#include <iostream>
#include <cstdlib>
#include <cstring>

void _start( int,  char ** );
void _help();
bool check_number( char * );
void dec2bin( int number );
int bin2dec( int number );

#endif
