#include <iostream>
#include "root.hh"
//using namespace root;


int main( int argc , char **argv ){
  root::Terminal term;
  term.terminal();
  term.root();
  return 0;
}

